package com.example.clases_ventas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
